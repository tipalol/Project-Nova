﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DemoObjectType : MonoBehaviour
{
    public string type ="default";
    
}
