﻿using UnityEngine;
using CommandTerminal;

public class CustomCommands : MonoBehaviour
{
    [RegisterCommand(Help = "Set last saved level", MinArgCount = 1, MaxArgCount = 1)]
    static void CommandSetLastLevel(CommandArg[] args)
    {
        string name = args[0].String;

        if (Terminal.IssuedError) return;

        PlayerPrefs.SetString("LastSceneName", name);
        Terminal.Log($"{name} will be loaded if continue", name);
    }

    [RegisterCommand(Help = "Load level", MinArgCount = 1, MaxArgCount = 1)]
    static void CommandLoadLevel(CommandArg[] args)
    {
        string name = args[0].String;

        if (Terminal.IssuedError) return;

        Initiate.Fade(name, new Color(0, 0, 0), 1f);
    }

    [RegisterCommand(Help = "WTF???", MinArgCount = 0, MaxArgCount = 0)]
    static void CommandWTF(CommandArg[] args)
    {
        if (Terminal.IssuedError) return;

        var spawner = Instantiate(Resources.Load<Spawner>("Prefabs/Spawner"), new Vector3(10, 13, 0), Quaternion.identity);
        Destroy(spawner, 15f);
    }

    [RegisterCommand(Help = "Die", MinArgCount = 0, MaxArgCount = 0)]
    static void CommandDie(CommandArg[] args)
    {
        if (Terminal.IssuedError) return;

        var player = GameObject.FindGameObjectWithTag("Player").GetComponent<Moving>();
        player.Die();
        Terminal.Log("ok....");
    }

    [RegisterCommand(Help = "Set current health", MinArgCount = 1, MaxArgCount = 1)]
    static void CommandSetHealth(CommandArg[] args)
    {
        float health = args[0].Float;

        if (Terminal.IssuedError) return;

        var player = GameObject.FindGameObjectWithTag("Player").GetComponent<Moving>();
        player.Health = health;
        player.HealthChanged?.Invoke();
        Terminal.Log("Done");
    }

    [RegisterCommand(Help = "Add exp", MinArgCount = 1, MaxArgCount = 1)]
    static void CommandAddExp(CommandArg[] args)
    {
        float exp = args[0].Float;

        if (Terminal.IssuedError) return;
        if (exp < 0)
        {
            Terminal.Log("Must be 0 or more");
            return;
        }

        var player = GameObject.FindGameObjectWithTag("Player").GetComponent<Moving>();

        player.CollectCoin(exp);

        player.CoinCollected?.Invoke();
        Terminal.Log("Done");
    }
}
