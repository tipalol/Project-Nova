﻿using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class Moving : MonoBehaviour
{
    private Transform _transform;
    private Rigidbody2D _rigidbody2d;
    private BoxCollider2D _collider;
    [SerializeField] private float _speed;
    [SerializeField] private float _chargeCooldown;
    private bool _canCharge;
    private Animator _animator;
    private bool _canMove;
    public Transform RespawnPoint;
    public GameUI GameUI;
    public bool IsDead { get; private set; }
    public bool ComingToNewLevel;
    public bool Invulnerability;
    public float Health;
    public float Exp { get; private set; }
    private bool _canStrike;
    public float StrikeCooldown;

    public UnityEvent CoinCollected;
    public UnityEvent HealthChanged;

    void Start()
    {
        _transform = GetComponent<Transform>();
        _rigidbody2d = GetComponent<Rigidbody2D>();
        _animator = GetComponent<Animator>();
        _collider = GetComponent<BoxCollider2D>();
        _canCharge = true;
        _canMove = true;
        IsDead = false;
        Invulnerability = false;
        Health = 2f;
        Exp = 0;
        _canStrike = true;

        if (PlayerPrefs.HasKey("Exp"))
            Exp = PlayerPrefs.GetFloat("Exp");

        GameUI.ExpText.text = $"Опыт: {Exp} поинтов";

        if (PlayerPrefs.HasKey("Health"))
            Health = PlayerPrefs.GetFloat("Health");

        GameUI.HealthText.text = $"Здоровье: {Health}";
        UpdateHealthData();

        CoinCollected.AddListener(PlayPopSound);
        CoinCollected.AddListener(CollectCoin);

        HealthChanged.AddListener(UpdateHealthData);

        var level = SceneManager.GetActiveScene().name;

        if (level == "FirstLevel")
        {
            BlockCharge();
            BlockStrike();
        }
        if (level.Contains("Second") || level.Contains("Third") || level.Contains("Fourth"))
        {
            BlockStrike();
        }

    }

    void Update()
    {
        if (Input.GetKey(KeyCode.D) && _canMove)
        {
            var velocity = _rigidbody2d.velocity;
            _rigidbody2d.velocity = new Vector2() { x = _speed, y = velocity.y};

            _animator.SetBool("isRunning", true);

            if (transform.localScale.x < 0)
            {
                var scale = transform.localScale;
                transform.localScale = new Vector2() { x = scale.x * (-1), y = scale.y};
            }
            
        }
        if (Input.GetKey(KeyCode.A) && _canMove)
        {
            var velocity = _rigidbody2d.velocity;
            _rigidbody2d.velocity = new Vector2() { x = -_speed, y = velocity.y};
            _animator.SetBool("isRunning", true);
            if (transform.localScale.x > 0)
            {
                var scale = transform.localScale;
                transform.localScale = new Vector2() { x = scale.x * (-1), y = scale.y};
            }
        }
        if (Input.GetKeyDown(KeyCode.Q) && _canMove && _canCharge)
        {
            Charge();
            if (GameUI != null)
                GameUI.StartChargeCooldown(_chargeCooldown);
            StartCoroutine(ChargeCooldown(_chargeCooldown));
        }

        if (Input.GetKeyDown(KeyCode.F) && _canMove && _canStrike)
        {
            _animator.SetTrigger("attack2");
            Strike();
        }

        

        if (Mathf.Abs(_rigidbody2d.velocity.x) < .5f && _canMove)
            _animator.SetBool("isRunning", false);
    }

    public void Respawn()
    {
        _canMove = true;
        Health = 2f;
        GameUI.UpdateHealth();
        _animator.ResetTrigger("death");
        _animator.Play("Default_Idle");
        IsDead = false;
        _rigidbody2d.constraints = RigidbodyConstraints2D.FreezeRotation;
        Vector3 eulerRotation = _transform.rotation.eulerAngles;
        _transform.rotation = Quaternion.Euler(eulerRotation.x, eulerRotation.y, 0);

        transform.position = RespawnPoint.position;
        _rigidbody2d.velocity = new Vector2(0, 0);
    }

    public void Charge()
    {
        var direction = transform.localScale.x > 0 ? 1 : -1;

        BecomeInvul(1.5f);

        _rigidbody2d.AddForce(Vector2.right * direction * _speed * 20, ForceMode2D.Impulse);

        _animator.SetTrigger("attack1");
    }

    private IEnumerator ChargeCooldown(float seconds)
    {
        _canCharge = false;
        yield return new WaitForSeconds(seconds);
        _canCharge = true;

        yield return null;
    }

    public void Die()
    {
        if (!ComingToNewLevel && !IsDead && !Invulnerability)
        {
            _canMove = false;
            _animator.SetTrigger("death");
            _rigidbody2d.constraints = RigidbodyConstraints2D.None;
            IsDead = true;
            StartCoroutine(RespawnCooldown(3f));
        }
    }

    private IEnumerator RespawnCooldown(float seconds)
    {
        _animator.SetTrigger("death");
        yield return new WaitForSeconds(seconds);
        Respawn();
        yield return null;
    }

    public void ComeToNewLevel()
    {
        _collider.isTrigger = true;
        _canMove = false;
        _rigidbody2d.velocity = new Vector2(0, 0);
        _rigidbody2d.constraints = RigidbodyConstraints2D.FreezeAll;
    }

    public void Hurt()
    {
        
        Health--;

        HealthChanged?.Invoke();

        if (Health <= 0f)
            Die();
        else
            _animator.SetTrigger("hurt");
    }

    public void BecomeInvul(float seconds)
    {
        Invulnerability = true;
        StartCoroutine(InvulCooldown(seconds));
    }

    private IEnumerator InvulCooldown(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        Invulnerability = false;
        yield return null;
    }

    private void PlayPopSound()
    {
        var sound = Instantiate(Resources.Load<GameObject>("Prefabs/PopSound"),
            transform.position,
            Quaternion.identity);

        Destroy(sound, 1);
    }

    public void CollectCoin()
    {
        Exp++;
        PlayerPrefs.SetFloat("Exp", Exp);
    }

    public void CollectCoin(float amount)
    {
        Exp += amount;
        PlayerPrefs.SetFloat("Exp", Exp);
    }

    public void UpdateHealthData()
    {
        PlayerPrefs.SetFloat("Health", Health);
    }

    public void Strike()
    {
        GetComponent<StrikeAbility>().Strike();
        StartCoroutine(StartStrikeCooldown(StrikeCooldown));
        if (GameUI != null)
            GameUI.StartStrikeCooldown(StrikeCooldown);
    }

    private IEnumerator StartStrikeCooldown(float seconds)
    {
        _canStrike = false;
        yield return new WaitForSeconds(seconds);
        _canStrike = true;

        yield return null;
    }

    private void BlockCharge()
    {
        StartCoroutine(ChargeCooldown(99999));
        GameUI.StartChargeCooldown(99999);
    }

    private void BlockStrike()
    {
        StartCoroutine(StartStrikeCooldown(99999));
        GameUI.StartStrikeCooldown(99999);
    }
}
