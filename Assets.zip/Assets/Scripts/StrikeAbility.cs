﻿using System.Collections;
using UnityEngine;

public class StrikeAbility : MonoBehaviour
{
    [SerializeField] private LayerMask _collideLayer;
    [SerializeField] private float _abilityDistance;
    [SerializeField] private float _abilityDelay;

    public void Strike()
    {
        StartCoroutine(Delay(_abilityDelay));
    }

    private Vector3 CalculateCenterPosition()
    {
        return new Vector3(transform.position.x, transform.position.y + 1, transform.position.z);
    }

    private IEnumerator Delay(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        if (!GetComponent<Moving>().IsDead)
        {
            var ray = Physics2D.Raycast(CalculateCenterPosition(), Vector2.right, _abilityDistance, _collideLayer);
            Destroy(ray.collider.gameObject);
        }
        yield return null;
    }
}
