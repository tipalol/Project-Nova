﻿using UnityEngine;

public class Gate : MonoBehaviour
{
    [SerializeField] private string _nextSceneName;

    public void Load()
    {
        var player = GameObject.FindGameObjectWithTag("Player").GetComponent<Moving>();
        if (!player.IsDead)
        {
            player.ComingToNewLevel = true;
            player.ComeToNewLevel();
            PlayerPrefs.SetString("LastSceneName", _nextSceneName);
            Initiate.Fade(_nextSceneName, Color.black, 1f);
        }
    }
}
