﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameUI : MonoBehaviour
{
    public Image ChargeIcon;
    public Image StrikeIcon;
    public TMPro.TextMeshProUGUI ExpText;
    public TMPro.TextMeshProUGUI HealthText;

    public Moving Player;

    private void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player").GetComponent<Moving>();
        Player.CoinCollected.AddListener(UpdateExp);
        Player.HealthChanged.AddListener(UpdateHealth);
    }

    public void UpdateExp()
    {
        ExpText.text = $"Опыт: {Player.Exp + 1} поинтов";
    }

    public void UpdateHealth()
    {
        HealthText.text = $"Здоровье: {Player.Health}";
    }

    public void StartChargeCooldown(float seconds)
    {
        StartCoroutine(ChargeCooldown(seconds));
        var oldColor = ChargeIcon.color;
        ChargeIcon.color = new Color(oldColor.r, oldColor.g, oldColor.b, 0.5f);
    }

    private IEnumerator ChargeCooldown(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        var oldColor = ChargeIcon.color;
        ChargeIcon.color = new Color(oldColor.r, oldColor.g, oldColor.b, 1f);
        yield return null;
    }

    public void StartStrikeCooldown(float seconds)
    {
        StartCoroutine(StrikeCooldown(seconds));
        var oldColor = StrikeIcon.color;
        StrikeIcon.color = new Color(oldColor.r, oldColor.g, oldColor.b, 0.5f);
    }

    private IEnumerator StrikeCooldown(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        var oldColor = StrikeIcon.color;
        StrikeIcon.color = new Color(oldColor.r, oldColor.g, oldColor.b, 1f);
        yield return null;
    }
}
