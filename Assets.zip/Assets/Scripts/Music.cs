﻿using UnityEngine;

public class Music : MonoBehaviour
{
    private Transform _player;
    // Start is called before the first frame update
    void Start()
    {
        DontDestroyOnLoad(this.gameObject);
        //_player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        //transform.position = _player.position;
    }
}
